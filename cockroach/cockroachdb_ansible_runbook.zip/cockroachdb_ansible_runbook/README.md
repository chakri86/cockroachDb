# CockroachDB Secure HA Lab - Ansible Automation

This project rebuilds the lab architecture used in the hands-on CockroachDB exercise:

- CockroachDB v26.2.3: coc1 (192.168.247.156), coc2 (192.168.247.198), coc3 (192.168.247.199)
- HAProxy pair: haproxy1 (192.168.247.200), haproxy2 (192.168.247.202)
- Keepalived VIP: 192.168.247.210 (`crdb-vip`)
- FastAPI application: app1 (192.168.247.201:8000)
- Database: `labdb`
- Application SQL user: `labapp`
- Secure TLS from the first deployment; HAProxy performs TCP pass-through and HTTPS `/health?ready=1` checks.

## 1. Controller prerequisites

Use an Ansible controller that can SSH to all hosts as `chakravarthi` and sudo to root.

```bash
python3 -m pip install ansible
ansible-galaxy collection install -r requirements.yml
```

Verify SSH and sudo:

```bash
ansible all -m ping
ansible all -b -m command -a 'id'
```

## 2. Review variables

Edit:

```text
inventory/lab/hosts.yml
inventory/lab/group_vars/all.yml
```

Create the vault file:

```bash
cp inventory/lab/group_vars/vault.yml.example inventory/lab/group_vars/vault.yml
ansible-vault encrypt inventory/lab/group_vars/vault.yml
```

Change `keepalived_auth_pass` in the encrypted file. Remove or override the placeholder in `all.yml` in production.

## 3. Syntax check and dry run

```bash
ansible-playbook playbooks/site.yml --syntax-check --ask-vault-pass
ansible-playbook playbooks/site.yml --check --diff --ask-vault-pass
```

Some commands, certificate generation, cluster initialization, and service start operations cannot be perfectly modeled by `--check`; use it as a preview, not proof of deployment.

## 4. Deploy

```bash
ansible-playbook playbooks/site.yml --ask-vault-pass
```

The playbook performs these phases:

1. Baseline RHEL packages, chrony, and firewall.
2. Install CockroachDB and create service directories.
3. Generate CA, node certificate, `root` client certificate, and `labapp` client certificate on coc1.
4. Securely distribute only the required certificates/keys. The CA private key remains on coc1.
5. Start all three CockroachDB nodes in secure mode and initialize the cluster once.
6. Configure both HAProxy nodes with TLS health checks on CockroachDB port 8080.
7. Configure Keepalived and floating VIP 192.168.247.210.
8. Create `labdb`, tables, `labapp`, and least-privilege grants.
9. Deploy FastAPI with `sslmode=verify-full`, client certificate authentication, and CockroachDB retry handling.
10. Run validation.

## 5. Validation

Run at any time:

```bash
ansible-playbook playbooks/validate.yml --ask-vault-pass
```

Manual checks:

```bash
# From coc1
/usr/local/bin/cockroach node status \
  --host=192.168.247.210:26257 \
  --certs-dir=/root/.cockroach-certs

# Insecure SQL must fail
/usr/local/bin/cockroach sql --insecure \
  --host=192.168.247.210:26257 \
  --database=labdb \
  --execute='SELECT 1;'

# Application
curl -s http://192.168.247.201:8000/health

# HAProxy stats
curl -s http://192.168.247.210:8404/stats
```

## 6. Application failover workload

On app1:

```bash
cd /opt/cockroach-app
source venv/bin/activate
python availability_test.py
```

Expected healthy output:

```text
health=200 | read=200 | write=201
```

After testing, remove generated records:

```sql
DELETE FROM employees WHERE department = 'HA Testing';
```

## 7. One CockroachDB node failure test

This playbook is intentionally scoped to one node only:

```bash
ansible-playbook playbooks/failover-test.yml \
  --limit coc1 \
  -e failover_target=coc1 \
  --ask-vault-pass
```

In a three-node RF3 cluster, losing one node preserves quorum. Losing two nodes removes quorum and should be tested manually only in the lab.

## 8. HAProxy / Keepalived failure test

Identify VIP owner:

```bash
ansible haproxy -b -m shell -a "ip -4 addr show ens160 | grep 192.168.247.210 || true"
```

Stop HAProxy and Keepalived on the active proxy manually while `availability_test.py` runs. The VIP should move to the standby node and application traffic should continue over TLS.

## 9. Important PKI handling

The controller `.artifacts/pki` directory temporarily contains deployment private keys. Protect it with mode 0700, do not commit it to source control, and move long-lived private material to an approved secret store after deployment.

The CA private key is created at:

```text
/root/cockroach-pki/ca-private/ca.key
```

on coc1 and is not copied to CockroachDB nodes or app1.

## 10. Production hardening before reuse

This package reproduces the lab and is deliberately understandable. Before production use, replace the lab PKI with enterprise PKI/Vault, use separate per-node certificates where required by policy, store secrets in Ansible Vault or an external secret manager, use trusted CA verification for HAProxy health checks instead of `verify none`, restrict firewall sources, run FastAPI under a dedicated OS account, add observability/backups, pin and verify binary checksums, and establish rolling upgrade/rollback procedures.
